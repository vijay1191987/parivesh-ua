const greeting = 'hello';

const name = 'James'
const MapConfig = {Token:"ASads"}

// 👇️ named exports (same as code snippet above)
export {greeting, name,MapConfig};