
const NICStreetmap = '5R5ftJZp67OS1L5l-xLGvAr1nGAHJi5Tq8GZN-IpCWL0m-eHYez26Dxh-XXJ-6Pu';
const Terrain = 'J5v_0Qf9lOFHIaX8fCGrpNDpqgIJ_tLlSD--Pgq10pjih3B7bfYmJe5DmdWiDQOj';
const Bharatmaps = '5ewlhladvLt1Pq7VEKutoe-1y7XqH7v_cvKCgvUcbS-GC94tqrrsftiWi-osv0H';


export { NICStreetmap, Terrain, Bharatmaps}

