import { DragableService } from 'src/app/services/dragable.service';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NestedTreeControl } from "@angular/cdk/tree";
import { MatTreeNestedDataSource } from "@angular/material/tree";


interface VehicleNode {
  name: string;
  id?: number;
  children?: VehicleNode[];
  selected?: boolean;
  indeterminate?: boolean;
  parent?: VehicleNode;
}

const TREE_DATA: VehicleNode[] = [
  {
    name: "Infiniti",
    children: [
      {
        name: "G50",
        children: [
          { name: "Pure AWD", id: 1 },
          { name: "Luxe", id: 2 }
        ]
      },
      {
        name: "QX50",
        children: [
          { name: "Pure AWD", id: 3 },
          { name: "Luxe", id: 4 }
        ]
      }
    ]
  },
  {
    name: "BMW",
    children: [
      {
        name: "2 Series",
        children: [
          { name: "Coupe", id: 5 },
          { name: "Gran Coupé", id: 6 }
        ]
      },
      {
        name: "3 Series",
        children: [
          { name: "Sedan", id: 7 },
          { name: "PHEV", id: 8 }
        ]
      }
    ]
  }
];


@Component({
  selector: 'app-layers',
  templateUrl: './layers.component.html',
  styleUrls: ['./layers.component.css']
})
//implements OnInit
export class LayersComponent implements OnInit {
  public treeControl = new NestedTreeControl<VehicleNode>(node => node.children);
  public dataSource = new MatTreeNestedDataSource<VehicleNode>();

  @ViewChild('outputDiv', { static: false })
  public outputDivRef_1: any = '';//  ElementRef<HTMLParagraphElement>='';


  constructor(public dragable: DragableService, public outputDivRef: ElementRef<HTMLParagraphElement>) {
    this.dataSource.data = TREE_DATA;
    Object.keys(this.dataSource.data).forEach((key: any) => {
      this.setParent(this.dataSource.data[key]);
    });
  }

  layersShow: boolean = false;
  layersIcon(idName: any) {
    this.layersShow = !this.layersShow;
    this.dragable.registerDragElement(idName);
  }

  hasChild = (_: number, node: VehicleNode) =>
    !!node.children && node.children.length > 0;

  public setParent(node: VehicleNode, parent: VehicleNode = {} as VehicleNode) {
    node.parent = parent;
    if (node.children) {
      node.children.forEach(childNode => {
        this.setParent(childNode, node);
      });
    }
  }

  checkAllParents(node: VehicleNode) {
    if (node.parent) {
      const descendants = this.treeControl.getDescendants(node.parent);
      node.parent.selected =
        descendants.every(child => child.selected);
      node.parent.indeterminate =
        descendants.some(child => child.selected);
      this.checkAllParents(node.parent);
    }
  }

  itemToggle(checked: boolean, node: VehicleNode) {
    node.selected = checked;
    if (node.children) {
      node.children.forEach(child => {
        this.itemToggle(checked, child);
      });
    }
    this.checkAllParents(node);
  }

  public submit() {
    let result = this.dataSource.data.reduce(
      (acc: string[], node: VehicleNode) =>
        acc.concat(this.treeControl
          .getDescendants(node)
          .filter(descendant => descendant.selected)
          .map(descendant => descendant.name))
      , [] as string[]);


    this.outputDivRef.nativeElement.innerText = 'You '
      + (result.length > 0
        ? 'selected ' + result.join(', ')
        : 'have not made a selection')
      + '.';
  }

  ngOnInit(): void {
  }
}
